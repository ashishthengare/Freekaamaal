var t = 0;
function load_more_on_button_click(){
	jQuery("#load_button_wrapper").hide();var a=jQuery("#nextoffset").val();jQuery("#nextoffset").remove();jQuery("#test-button").show(),jQuery("#test-button").html('Loading...&nbsp;&nbsp;<img alt="" src="'+img_base_url+'common-images/ajax-loader.gif" style="vertical-align: middle;"/>');
	setTimeout(function() {
		jQuery.ajax({url:base_url+"hot/"+a+"/16",cache:!1,async:true,type:"POST",data:"action=infinite_scroll&offset="+a+"&loop_file=loop_infiny",success:function(b)
		{
				jQuery("#load_button_wrapper").remove();
				1==b?(jQuery("#noajax").val("1"),jQuery("#test-button").hide(),jQuery("#noneed1").show()):(a=parseInt(a)+16,jQuery(".countpagee").val(a),jQuery("#load_button_wrapper").show(),jQuery("#test-button").html('Loading...&nbsp;&nbsp;<img alt="" src="'+img_base_url+'common-images/ajax-loader.gif" style="vertical-align: middle;"/>').hide(0),jQuery("#homepagedealmain").append(b),isDone=!0);
				html='<div class="col-md-12 text-center" id="load_button_wrapper" style="padding-bottom: 25px;"><input type="button" class="mtop-10  my-load-more" id="load_more_button" onclick="load_more_on_button_click()" value="Load More"></div>';
				
				jQuery("#load_button_wrapper").remove();
				jQuery("#test-button").html("");
				jQuery("#homepagedealmain").append(html);
				console.log(html)
		}
			,complete:function(a,b){}})
	},1000);

}

function loadArticle(a){
	if(a <= 2)
	{
		
		jQuery("#test-button").show();
		jQuery("#test-button").html('Loading...&nbsp;&nbsp;<img alt="" src="'+img_base_url+'common-images/ajax-loader.gif" style="vertical-align: middle;"/>');	
		
		if(t==0)
		{
			t = 1;
			jQuery.ajax({
				url:base_url+"hot/"+a+"/16",
				cache:!1,
				async:!1,
				type:"POST",
				data:"action=infinite_scroll&offset="+a+"&loop_file=loop_infiny",
				success:function(b){
					1==b?(jQuery("#noajax").val("1"),jQuery("#test-button").hide(),jQuery("#noneed1").show()):(a=parseInt(a)+16,jQuery(".countpagee").val(a),jQuery("#test-button").html('Loading...&nbsp;&nbsp;<img alt="" src="'+img_base_url+'common-images/ajax-loader.gif" style="vertical-align: middle;"/>').show(),jQuery("#nextoffset").remove(),jQuery("#homepagedealmain").append(b),isDone=!0)
				t=0;
				},complete:function(a,b){t=0;}
			});
		}
		html='<div class="col-md-12 text-center" id="load_button_wrapper" style="padding-bottom: 25px;"><input type="button" class="mtop-10  my-load-more" id="load_more_button" onclick="load_more_on_button_click()" value="Load More"></div>';
		jQuery("#load_button_wrapper").remove();
		jQuery("#test-button").html("");
		jQuery("#homepagedealmain").append(html);
	}
return 1;	
}

var loadOnScroll=function()
{
	if(jQuery(window).scrollTop()>jQuery(document).height()-3*jQuery(window).height()-850)
	{
		var a=jQuery("#nextoffset").val(),
		b=jQuery(".notrending").val(),
		c=jQuery("#noajax").val();
		void 0!==a&&0==c&&0!=b&&loadArticle(a)
	}
},
is_running=!1;
$(window).scroll(function()
{
0==is_running&&(is_running=!0,loadOnScroll(),is_running=!1)
});

